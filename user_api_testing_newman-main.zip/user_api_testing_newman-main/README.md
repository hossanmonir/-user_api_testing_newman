# user_api_testing_newman
1. Clone the repo
2. Give this command:
 ```
 npm i
 ```
3. Give this command to run

```
npm test
```
